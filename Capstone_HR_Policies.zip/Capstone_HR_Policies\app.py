import streamlit as st
import os
import pandas as pd
import PyPDF2
from dotenv import load_dotenv

from langchain_google_genai import GoogleGenerativeAIEmbeddings, ChatGoogleGenerativeAI
from langchain_community.vectorstores import FAISS
from langchain_text_splitters import RecursiveCharacterTextSplitter

from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import HumanMessage, AIMessage

load_dotenv()

st.set_page_config(page_title="HR Policies Document Assistant", layout="wide")
st.title("Enterprise AI - HR Policies Query System")

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "vector_store" not in st.session_state:
    st.session_state.vector_store = None

def get_file_text(upload_files):
    text = ""
    for file in upload_files:
        if file.name.endswith(".pdf"):
            pdf_reader = PyPDF2.PdfReader(file)
            for page in pdf_reader.pages:
                if page.extract_text():
                    text += page.extract_text() + "\n"
        elif file.name.endswith(".txt"):
            text += file.getvalue().decode("utf-8") + "\n"
        elif file.name.endswith(".csv"):
            df = pd.read_csv(file)
            text += df.to_string() + "\n"
        elif file.name.endswith(".xlsx"):
            df = pd.read_excel(file)
            text += df.to_string() + "\n"
    return text

def get_text_chunks(text):
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    chunks = text_splitter.split_text(text)
    return chunks

def get_vector_store(text_chunks):
    embeddings = GoogleGenerativeAIEmbeddings(model="models/gemini-embedding-2")
    vector_store = FAISS.from_texts(text_chunks, embedding=embeddings)
    return vector_store

def create_agent(vector_store):
    from langchain_core.runnables import RunnablePassthrough
    from langchain_core.output_parsers import StrOutputParser
    
    llm = ChatGoogleGenerativeAI(model="gemini-3.5-flash", temperature=0)
    retriever = vector_store.as_retriever()
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are an expert AI assistant. Use the following pieces of retrieved context to answer the user's question. If you don't know the answer, say you don't know. Always base your reasoning on the retrieved context.\n\nContext:\n{context}"),
        MessagesPlaceholder(variable_name="chat_history"),
        ("user", "{input}"),
    ])
    
    def format_docs(docs):
        return "\n\n".join(doc.page_content for doc in docs)
        
    from operator import itemgetter
    
    rag_chain = (
        {
            "context": itemgetter("input") | retriever | format_docs, 
            "input": itemgetter("input"), 
            "chat_history": itemgetter("chat_history")
        }
        | prompt
        | llm
        | StrOutputParser()
    )
    return rag_chain

with st.sidebar:
    st.subheader("Your Documents")
    uploaded_files = st.file_uploader(
        "Upload your PDFs, TXTs, CSVs or Excel files here and click on 'Process'", 
        accept_multiple_files=True,
        type=['pdf', 'txt', 'csv', 'xlsx']
    )
    if st.button("Process"):
        with st.spinner("Processing..."):
            if not uploaded_files:
                st.warning("Please upload files first.")
            else:
                try:
                    raw_text = get_file_text(uploaded_files)
                    text_chunks = get_text_chunks(raw_text)
                    st.session_state.vector_store = get_vector_store(text_chunks)
                    st.success("Documents processed successfully!")
                except Exception as e:
                    st.error(f"Error processing documents: {e}")

# Display chat messages from history on app rerun
for message in st.session_state.chat_history:
    role = "user" if isinstance(message, HumanMessage) else "assistant"
    with st.chat_message(role):
        st.write(message.content)

user_question = st.chat_input("Ask a question about your HR Policies documents:")

if user_question:
    if st.session_state.vector_store is None:
        st.warning("Please upload and process documents first.")
    else:
        st.session_state.chat_history.append(HumanMessage(content=user_question))
        with st.chat_message("user"):
            st.write(user_question)
            
        with st.spinner("Thinking..."):
            try:
                agent = create_agent(st.session_state.vector_store)
                response = agent.invoke({
                    "input": user_question,
                    "chat_history": st.session_state.chat_history
                })
                
                ai_response = response
                st.session_state.chat_history.append(AIMessage(content=ai_response))
                
                with st.chat_message("assistant"):
                    st.write(ai_response)
            except Exception as e:
                st.error(f"An error occurred during response generation: {e}")
