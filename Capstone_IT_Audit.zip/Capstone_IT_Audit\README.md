# Generative AI Capstone Project: IT Audit Query System

## Overview
This project is a Generative AI-powered application that enables users to query IT Audit documents using an autonomous AI agent. It utilizes Retrieval-Augmented Generation (RAG) and Agentic AI frameworks to retrieve relevant information from uploaded documents (PDF, TXT, CSV, Excel), reason over it, and generate accurate responses.

## Architecture
- **Frontend**: Streamlit is used for the user interface, providing document upload and a chat-like querying interface.
- **Document Ingestion**: PyPDF2, pandas, and openpyxl are used to extract text from various document formats.
- **Embedding & Vector Store**: Google Gemini Embeddings and FAISS (Facebook AI Similarity Search) are used to convert text chunks into vectors and store them for fast semantic search.
- **Agentic Framework**: LangChain's LCEL architecture is used to give the LLM access to the vector store via a retriever tool. The chain grounds its response on the extracted context.
- **LLM**: Google Gemini 3.5-flash model is utilized to reason and generate the final responses.

## System Setup & Deployment
1. **Prerequisites**: Python 3.9+
2. **Installation**:
   ```bash
   pip install -r requirements.txt
   ```
3. **Environment Setup**:
   Create a `.env` file in the root directory and add your Google Gemini API Key:
   ```
   GOOGLE_API_KEY=your_gemini_api_key_here
   ```
   (Note: The submitted project already contains the provided API key in the `.env` file).
4. **Run the Application**:
   ```bash
   streamlit run app.py
   ```

## Agent Roles
- **Planner/Reasoning Agent**: The core LLM acting as an IT Audit expert. It determines if the user's query requires searching the document base.
- **Retriever Tool**: An interface for the agent to semantically search the FAISS vector database and extract the most relevant chunks of text.

## Limitations & Challenges
- **Token Limits**: Very large documents might exceed the context window, though RAG mitigates this by only retrieving top chunks.
- **Table Parsing**: Extracting complex tables from PDFs can sometimes lose formatting, which might affect the LLM's understanding of tabular IT Audit data. CSV and Excel files are handled better via pandas.
- **Hallucinations**: While guardrails are in place (prompting the agent to say "I don't know" if the context is missing), large language models may occasionally hallucinate or infer information not strictly present in the text.
